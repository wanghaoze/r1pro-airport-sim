"""Geometry-parameterized, bounded-time actions; no waypoint stop fallback.

The three-second contract is simulation time INCLUDING contact verification.
Navigation and initial grasp acquisition are separate, explicitly labelled states.
No state resets, object attachments, time scaling or successful timeout labels.
"""
from contextlib import contextmanager
import math
import time
import numpy as np
from .contracts import Fault, ARM_COLUMNS, State, wrap_angle
from .geometry import quat_yaw_tilt, rz
from .trajectory import CruiseJointPath, BlendedJointPath, entry_limit_envelope


@contextmanager
# 统一控制时间预算；墙钟规划耗时单独记录，失败不能伪装为成功。
def action(machine, name, **parameters):
    r=machine.r;start=r.steps;wall=time.monotonic()
    if getattr(r,'primitive_deadline_step',None) is not None:
        raise Fault('nested_primitive')
    r.primitive_deadline_step=start+math.floor(machine.c.primitive_seconds*machine.c.fps)
    try:
        machine.log.event('primitive_start',primitive=name,limit_s=machine.c.primitive_seconds,parameters=parameters)
        yield
    except Fault as exc:
        machine.log.event('primitive_failed',primitive=name,reason=exc.code,detail=exc.detail,
                          duration_s=(r.steps-start)/machine.c.fps)
        # Never follow a rejected fast action with an unlabelled slow retry.
        raise Fault(exc.code,exc.detail,recoverable=False) from exc
    else:
        machine.log.event('primitive_complete',primitive=name,duration_s=(r.steps-start)/machine.c.fps,
                          planning_and_execution_wall_s=time.monotonic()-wall)
    finally:
        r.primitive_deadline_step=None


def remaining(r):
    return (r.primitive_deadline_step-r.steps)/r.cfg.fps


# 先验证整段路径再执行；禁止通过放宽限位或忽略刚性夹持误差换取速度。
def plan(r, points, *, available, minimum=.1, allow_shortcut=False):
    """Select a whole C2 reference before motion; reject rather than speed-limit bypass."""
    points=np.asarray(points,float)
    low,high=r.m.jnt_range[r.jids].T
    lo,hi=entry_limit_envelope(points[:,ARM_COLUMNS],low,high,r.cfg.joint_margin_rad)
    reasons=[];prepared=[];seen=set()
    candidates=[(kind,points) for kind in (CruiseJointPath,BlendedJointPath)]
    if allow_shortcut:
        for n in (2,3,4,5):
            subset=points[np.unique(np.round(np.linspace(0,len(points)-1,n)).astype(int))]
            candidates.extend((kind,subset) for kind in (CruiseJointPath,BlendedJointPath))
        for middle in range(1,len(points)-1):
            candidates.extend((kind,points[[0,middle,-1]]) for kind in (CruiseJointPath,BlendedJointPath))
            linear=points[0]+(points[-1]-points[0])*middle/(len(points)-1)
            for weight in (.25,.5,.75):
                subset=np.stack([points[0],linear+weight*(points[middle]-linear),points[-1]])
                candidates.extend((kind,subset) for kind in (CruiseJointPath,BlendedJointPath))
    for kind,knots in candidates:
        identity=(kind.__name__,knots.shape,knots.tobytes())
        if identity in seen:continue
        seen.add(identity)
        path=kind(knots,r.v,r.a,r.j,minimum)
        frames=math.ceil(path.duration*r.cfg.fps);duration=frames/r.cfg.fps
        if duration>available+1e-9:
            reasons.append({'mode':kind.__name__,'reason':'duration','required_s':duration});continue
        prepared.append((duration,path,frames))
    # Same minimum-duration choice as exhaustive validation, but stop checking
    # slower candidates once a valid faster path is found. Stable sorting keeps
    # the previous tie-breaking order and therefore the selected reference.
    for duration,path,frames in sorted(prepared,key=lambda x:x[0]):
        kind=type(path)
        reason=r._path_rejection(path,max(64,len(points)*16),lo,hi,True)
        if reason is not None:
            reasons.append({'mode':kind.__name__,**reason});continue
        try:
            for u in np.linspace(0,1,21):
                q,v,a,_=path.evaluate(u,duration)
                r.audit_online_reference(q,v,a)
        except Fault as exc:
            reasons.append({'mode':kind.__name__,'reason':exc.code});continue
        return path,frames
    raise Fault('primitive_path_infeasible',{'available_s':available,'candidates':reasons})


def execute(r, planned, predicate=None):
    path,frames=planned
    if frames>r.primitive_deadline_step-r.steps:raise Fault('primitive_insufficient_time')
    duration=frames/r.cfg.fps
    r.trace.event('primitive_reference',duration_s=duration,controller=type(path).__name__,
                  knot_stop_fallback=False,reference_bounds=path.reference_bounds)
    consecutive=0
    for frame in range(1,frames+1):
        r.sim.target=path.evaluate(frame/frames,duration)[0]
        r.tick()
        if predicate is not None:consecutive=consecutive+1 if predicate(r.observation()) else 0
    return consecutive


def settle(r, predicate, seconds, stable_frames=2):
    count=math.ceil(seconds*r.cfg.fps)
    if count>r.primitive_deadline_step-r.steps:raise Fault('primitive_no_verification_budget')
    consecutive=0
    for _ in range(count):
        r.tick()
        consecutive=consecutive+1 if predicate(r.observation()) else 0
    if consecutive<min(stable_frames,count):
        x=r.observation();t=r.allowed_tray
        raise Fault('primitive_postcondition_failed',{'stable_frames':consecutive,
                    'tray_pose':x['tray_pose'][t],'bottom_z':float(x['min_z'][t]),
                    'table_contact':int(x['table_contact'][t]),'gripper_force':x['gripper_contact_force'][t]})


def await_table_support(r, tray, reserved_release_s):
    """Spend only the unused place budget on physical touchdown, never on opening.

    The descent can finish micrometres above the table while the force-limited
    servo is still settling. Keep its target unchanged until contact is observed,
    reserving the full preplanned release duration inside the same 3 s action.
    """
    frames = max(0, r.primitive_deadline_step-r.steps-round(reserved_release_s*r.cfg.fps))
    for _ in range(frames):
        if r.observation()['table_contact'][tray] > 0:
            return
        r.tick()
    if r.observation()['table_contact'][tray] > 0:
        return
    x=r.observation()
    raise Fault('primitive_touchdown_not_observed',{
        'reserved_release_s':reserved_release_s,'waited_frames':frames,
        'bottom_z':float(x['min_z'][tray]),'table_contact':int(x['table_contact'][tray])})


def object_points(r, position, yaw=None):
    from .runtime import _homogeneous
    b=r.d.body(r.g.ids[r.holding]);R=b.xmat.reshape(3,3).copy() if yaw is None else rz(yaw)
    T=_homogeneous(position,R)
    goals={s:((T@rel)[:3,3],(T@rel)[:3,:3]) for s,rel in r.grasp_rel.items()}
    return r.cartesian(goals,opening=r.cfg.gripper_close_m,wrist=True,preview_only=True)


def continue_loaded_reference(r):
    """Preserve measured servo compression instead of resetting it at each move.

These are COMMAND offsets, not observed object poses or synthetic contacts.
Actual bilateral forces and the complete physics guards remain authoritative.
"""
    from .runtime import _homogeneous
    b=r.d.body(r.g.ids[r.holding]);T=_homogeneous(b.xpos,b.xmat.reshape(3,3))
    shadow=r._shadow(r.sim.target)
    rel={};errors={}
    for side in ('left','right'):
        site=shadow.site(side+'_tcp');p=site.xpos.copy();R=site.xmat.reshape(3,3).copy()
        errors[side]=float(np.linalg.norm(p-r.sim.tcp(side)[0]))
        if errors[side]>.05:raise Fault('primitive_excess_servo_deflection',errors)
        rel[side]=np.linalg.inv(T)@_homogeneous(p,R)
    r.grasp_rel=rel
    r.trace.event('primitive_command_compliance_reference',tcp_deflection_m=errors,
                  qualification='command_reference_only_not_observed_rigid_attachment')


# 高度依据托盘实际离桌距离验收，不用末端执行器指令位移替代。
def lift(machine,tray):
    r=machine.r;c=machine.c;e=r.observation()
    start_bottom=float(e['min_z'][tray])
    with action(machine,'lift',height_m=c.primitive_lift_m,accepted_height_m=[.15,.20]):
        continue_loaded_reference(r)
        target=e['tray_pose'][tray,:3].copy()
        target[2]+=c.primitive_lift_m+c.primitive_lift_compensation_m
        machine.transition(State.GRASP_TRAY,'lift')
        toward=r.d.body('base_link').xpos[:2]-target[:2]
        toward=toward/max(float(np.linalg.norm(toward)),1e-9)
        planned=None;failures=[]
        # At the workspace rim a purely vertical lift can be unreachable.
        # Preplan a small inward tuck while preserving the SAME lift height;
        # this performs no live retry, release, or intermediate waypoint stop.
        for inward in (0.,.02,-.02,.04,-.04,.06,-.06):
            candidate=target.copy();candidate[:2]+=inward*toward
            if inward:
                candidate[2]+=max(0.,min(.02,.20-c.primitive_lift_m-c.primitive_lift_compensation_m))
            try:
                points=object_points(r,candidate)
                planned=plan(r,points,available=remaining(r)-c.primitive_settle_s,allow_shortcut=True)
            except Fault as exc:
                if exc.code not in ('ik_unreachable','coupled_ik_unreachable','ik_branch_jump','primitive_path_infeasible'):
                    raise
                failures.append({'inward_m':inward,'reason':exc.code,'detail':exc.detail})
                continue
            machine.log.event('primitive_lift_path_selected',inward_m=inward,target_position=candidate,
                              command_height_m=float(candidate[2]-e['tray_pose'][tray,2]),
                              rejected_candidates=failures)
            r.primitive_lift_xy_shift_m=abs(inward)
            break
        if planned is None:raise Fault('primitive_lift_path_unavailable',failures)
        execute(r,planned)
        machine.transition(State.GRASP_TRAY,'stabilize')
        def accepted(x):
            h=float(x['min_z'][tray]-start_bottom)
            return (.15<=h<=.20 and x['support_contact'][tray]==0 and
                    np.all(x['gripper_contact_force'][tray]>c.criteria.contact_n) and
                    quat_yaw_tilt(x['tray_pose'][tray,3:])[1]<=np.deg2rad(c.criteria.tilt_deg))
        settle(r,accepted,c.primitive_settle_s)
        machine.log.event('primitive_lift_measured',height_m=float(r.observation()['min_z'][tray]-start_bottom))
        # Keep the validated commanded pair relationship for navigation.
        # Replacing it here with compliance-shifted measured TCP transforms
        # invalidates the unchanged command at the start of every base route.
        # Arrival planning remeasures both contact and command references.


# 桌面真实承重后才释放；衔接推动时保留一侧接触。
def place(machine,operation,staged):
    """One local descent plus confirmed unloading/release; base travel is separate."""
    r=machine.r;c=machine.c;tray=operation.tray;e=r.observation()
    table=machine.g.support_table(staged)
    if table is None:raise Fault('primitive_place_no_table')
    top=machine.g.tables[table]['dimensions_m'][2]
    need_push=np.linalg.norm(staged[:2]-operation.destination[:2])>.01
    keep=None
    if need_push and c.keep_place_contact:
        direction=operation.destination[:2]-staged[:2]
        keep=min(('left','right'),key=lambda s:np.dot(r.sim.tcp(s)[0][:2]-staged[:2],direction))
    release=[s for s in ('left','right') if s!=keep]
    # Explicit transport endpoint, not repeated corrections hidden in place.
    # It has its own complete three-second budget and audit event.
    combined_descent=getattr(r,'primitive_lift_xy_shift_m',0.)>.005
    if not combined_descent:
        with action(machine,'transport_align',destination_xy=staged[:2]):
            continue_loaded_reference(r)
            current=r.observation()['tray_pose'][tray]
            aligned=current[:3].copy();aligned[:2]=staged[:2]
            yaw,_=quat_yaw_tilt(current[3:]);goal_yaw=yaw+float(wrap_angle(operation.yaw-yaw,machine.g.period))
            points=object_points(r,aligned,goal_yaw)
            machine.transition(State.TRANSPORT_TRAY,'preplace')
            execute(r,plan(r,points,available=remaining(r)-c.primitive_settle_s,allow_shortcut=True))
            settle(r,lambda x:np.linalg.norm(x['tray_pose'][tray,:2]-staged[:2])<=c.criteria.position_m,c.primitive_settle_s)
    e=r.observation()
    with action(machine,'place',table_height_m=top,staged=staged,retained_side=keep):
        machine.transition(State.PLACE_TRAY,'descend')
        continue_loaded_reference(r)
        offset=float(e['tray_pose'][tray,2]-e['min_z'][tray])
        target=e['tray_pose'][tray,:3].copy();target[2]=top+offset-c.primitive_touchdown_preload_m
        yaw,_=quat_yaw_tilt(e['tray_pose'][tray,3:])
        if combined_descent:
            target[:2]=staged[:2]
            yaw=yaw+float(wrap_angle(operation.yaw-yaw,machine.g.period))
            # Bottom height must correspond to the TARGET orientation. Using
            # the tilted arrival's corner offset after leveling leaves a
            # systematic 1-2 cm hover above the table.
            vertices=r.evidence.local_vertices[r.m.body(machine.g.ids[tray]).id]
            offset=-float((vertices@rz(yaw).T)[:,2].min())
            target[2]=top+offset-c.primitive_touchdown_preload_m
        points=object_points(r,target,yaw if combined_descent else None)
        machine.log.event('primitive_descent_geometry',combined_xy_descent=combined_descent,target_position=target)
        if combined_descent and keep:
            for s in release:
                col=7 if s=='left' else 15;start=float(points[0][col])
                preload=max(c.gripper_close_m,float(r.sim.state()[col])-.005)
                for i,point in enumerate(points):point[col]=start+(preload-start)*i/max(1,len(points)-1)
            machine.log.event('primitive_supported_release_preload',sides=release,
                              qualification='fingers_remain_clamped_until_measured_table_contact')
        # Release only enough to clear measured fingers; the ordinary open
        # limit remains unchanged. Full opening may follow during retreat.
        release_start=np.array(points[-1],float);release_end=release_start.copy()
        for s in release:
            col=7 if s=='left' else 15
            release_end[col]=min(c.gripper_open_m,float(r.sim.state()[col])+c.primitive_release_clearance_m)
            if combined_descent and keep:release_end[col]=c.gripper_open_m
        release_plan=plan(r,[release_start,release_end],available=remaining(r)-.3)
        release_s=release_plan[1]/c.fps
        descent=plan(r,points,available=remaining(r)-release_s-.1,allow_shortcut=True)
        machine.transition(State.PLACE_TRAY,'descend')
        support_frames=execute(r,descent,lambda x:x['table_contact'][tray]>0)
        machine.transition(State.PLACE_TRAY,'support_contact')
        # Touchdown authorizes STARTING the smooth opening ramp. Table support
        # is checked throughout that ramp; final placement still needs stable
        # release observations and the task's separate one-second acceptance.
        if support_frames<1:await_table_support(r,tray,release_s)
        r.holding=None;r.grasp_rel=None
        if keep:r.retained_contact=(tray,keep);r.check_retained_contact()
        cols=[0 if s=='left' else 1 for s in release]
        def placed(x):
            pose=x['tray_pose'][tray];a,tilt=quat_yaw_tilt(pose[3:])
            return (x['table_contact'][tray]>0 and
                np.all(x['gripper_contact_force'][tray,cols]<=c.criteria.contact_n) and
                np.linalg.norm(pose[:3]-staged)<=c.criteria.position_m and
                abs(wrap_angle(a-operation.yaw,machine.g.period))<=np.deg2rad(c.criteria.yaw_deg) and
                tilt<=np.deg2rad(c.criteria.tilt_deg))
        machine.transition(State.PLACE_TRAY,'open')
        release_frames=execute(r,release_plan,placed)
        if release_frames<2:
            x=r.observation()
            raise Fault('primitive_release_not_verified',{'stable_frames':release_frames,
                'force':x['gripper_contact_force'][tray],'table_contact':int(x['table_contact'][tray]),
                'pose':x['tray_pose'][tray],'command_opening':r.sim.target[[7,15]],
                'measured_opening':r.sim.state()[[7,15]]})
    if keep:
        return machine.push(operation,retained_side=keep)
    machine.retreat()
    return False


# 保留接触手沿桌面推进，释放手避让；最终间隙在释放后的稳定阶段验收。
def push(machine,operation,side,relation,*,separation=False,free_retreat=False):
    from .runtime import _homogeneous
    r=machine.r;c=machine.c;tray=operation.tray
    with action(machine,'push',destination=operation.destination,yaw=operation.yaw,separation=separation):
        free_goal=None
        withdraw_free=False
        if free_retreat:
            free='right' if side=='left' else 'left';p,R=r.sim.tcp(free)
            withdraw_free=getattr(r,'primitive_lift_xy_shift_m',0.)>.005
            p[2]+=.10
            if withdraw_free:p[:2]-=.06*r.d.body('base_link').xmat.reshape(3,3)[:2,0]
            free_goal=(free,p,R)
        e=r.observation();actual=e['tray_pose'][tray];yaw,_=quat_yaw_tilt(actual[3:])
        if free_retreat:
            # Continue the already loaded retained hand's COMMAND relationship.
            # Reconstructing from the deflected measured TCP discards its servo
            # compression, leaving a systematic short push at every handoff.
            shadow=r._shadow(r.sim.target).site(side+'_tcp')
            measured=r.sim.tcp(side)[0]
            error=float(np.linalg.norm(shadow.xpos-measured))
            if error>.05:raise Fault('primitive_excess_servo_deflection',{side:error})
            body=r.d.body(machine.g.ids[tray])
            relation=np.linalg.inv(_homogeneous(body.xpos,body.xmat.reshape(3,3)))@_homogeneous(shadow.xpos,shadow.xmat.reshape(3,3))
            machine.log.event('primitive_push_compliance_reference',side=side,tcp_deflection_m=error,
                              qualification='command_reference_only_not_observed_rigid_attachment')
        delta=operation.destination[:2]-actual[:2]
        position=actual[:3].copy();position[:2]=operation.destination[:2]
        # Body height alone is not a support target: tiny servo/tilt changes
        # can leave the tray hovering. Use collision vertices at the intended
        # rotation and command normal preload; still require measured contact.
        table=machine.g.support_table(position)
        if table is None:raise Fault('primitive_push_no_table')
        vertices=r.evidence.local_vertices[r.m.body(machine.g.ids[tray]).id]
        target_rotation=(rz(float(wrap_angle(operation.yaw-yaw,machine.g.period)))
                         @r.d.body(machine.g.ids[tray]).xmat.reshape(3,3))
        preload=1.5*c.primitive_touchdown_preload_m if withdraw_free else min(.001,c.primitive_touchdown_preload_m)
        position[2]=(machine.g.tables[table]['dimensions_m'][2]
                     -float((vertices@target_rotation.T)[:,2].min())
                     -preload)
        machine.log.event('primitive_push_support_height',target_body_z_m=float(position[2]),
                          command_preload_m=preload)
        feedforward=.012 if separation else c.primitive_push_compensation_m
        if withdraw_free:feedforward=min(feedforward,.020)
        position[:2]+=feedforward*delta/max(float(np.linalg.norm(delta)),1e-9)
        machine.log.event('primitive_push_feedforward',distance_m=feedforward,
                          nominal_destination=operation.destination,command_position=position)
        R=r.d.body(machine.g.ids[tray]).xmat.reshape(3,3).copy()
        R=rz(float(wrap_angle(operation.yaw-yaw,machine.g.period)))@R
        T=_homogeneous(position,R)@relation
        goals={side:(T[:3,3],T[:3,:3])}
        if free_goal is not None:goals[free_goal[0]]=(free_goal[1],free_goal[2])
        # Free-arm clearance and the held-arm push share ONE continuous path.
        # Preserve the free gripper's open target; only the retained hand closes.
        points=r.cartesian(goals,wrist=True,preview_only=True)
        for point in points:point[7 if side=='left' else 15]=c.gripper_close_m
        if withdraw_free:
            col=7 if free=='left' else 15;start=float(points[0][col])
            for i,point in enumerate(points):point[col]=start+(c.gripper_open_m-start)*i/max(1,len(points)-1)
        available=remaining(r)-c.primitive_settle_s
        if withdraw_free:
            free_points=r.cartesian({free:(free_goal[1],free_goal[2])},opening=c.gripper_open_m,
                                    wrist=True,preview_only=True)
            # Give the released fingers clearance BEFORE the tray reaches
            # them. Keep this intermediate knot in the single C2 reference.
            from scipy.spatial.transform import Rotation,Slerp
            previous=np.array(free_points[-1],float);shadow=r._shadow(previous).site(side+'_tcp')
            start_p=shadow.xpos.copy();start_R=shadow.xmat.reshape(3,3).copy()
            rotations=Slerp([0,1],Rotation.from_matrix(np.stack([start_R,T[:3,:3]])))
            count=max(1,math.ceil(float(np.linalg.norm(T[:3,3]-start_p))/.025))
            held_points=[previous.copy()]
            for u in np.linspace(0,1,count+1)[1:]:
                previous=r.solve_pair({side:(start_p+u*(T[:3,3]-start_p),rotations(u).as_matrix())},previous)
                previous[7 if side=='left' else 15]=c.gripper_close_m
                held_points.append(previous.copy())
            middle=np.array(free_points[-1],float)
            cols=np.arange(0,7) if side=='left' else np.arange(8,15)
            middle[cols]+=.3*(held_points[-1][cols]-middle[cols])
            points=np.stack([points[0],middle,held_points[len(held_points)//2],held_points[-1]])
        execute(r,plan(r,points,available=available,minimum=min(2.4,available-.05),allow_shortcut=not withdraw_free))
        def accepted(x):
            pose=x['tray_pose'][tray];a,_=quat_yaw_tilt(pose[3:])
            geometry=(not machine.g.blockers(x['tray_pose'],tray,pose[:3],a,.085)) if separation else (
                np.linalg.norm(pose[:2]-operation.destination[:2])<=c.criteria.position_m and
                abs(wrap_angle(a-operation.yaw,machine.g.period))<=np.deg2rad(c.criteria.yaw_deg))
            # Final neighbour clearance is checked after measured release in
            # Machine.verify_operation; a loaded gripper elastically biases yaw.
            if free_retreat:
                geometry=geometry and x['gripper_contact_force'][tray,1 if side=='left' else 0]<=c.criteria.contact_n
            return geometry and x['table_contact'][tray]>0 and x['gripper_contact_force'][tray,0 if side=='left' else 1]>c.criteria.contact_n
        settle(r,accepted,c.primitive_settle_s)
