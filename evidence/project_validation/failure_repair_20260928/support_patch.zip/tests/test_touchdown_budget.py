from types import SimpleNamespace
import pytest
from r1pro_teleop.airport_fsm.primitives import await_table_support
from r1pro_teleop.airport_fsm.contracts import Config,Fault


def runtime(contact_at):
    r=SimpleNamespace(cfg=Config(),steps=35,primitive_deadline_step=60)
    def tick():r.steps+=1
    r.tick=tick
    r.observation=lambda:{'table_contact':[int(r.steps>=contact_at)],'min_z':[.80005]}
    return r


def test_touchdown_can_settle_beyond_old_two_frames_without_stealing_release_time():
    r=runtime(40);await_table_support(r,0,1.)
    assert r.steps==40 and r.primitive_deadline_step-r.steps==20


def test_no_contact_rejects_without_opening_or_extending_deadline():
    r=runtime(100)
    with pytest.raises(Fault,match='primitive_touchdown_not_observed'):await_table_support(r,0,1.)
    assert r.steps==40


def test_existing_contact_has_no_extra_delay():
    r=runtime(35);await_table_support(r,0,1.)
    assert r.steps==35
