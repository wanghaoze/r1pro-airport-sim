# 场景生成与托盘整理统一规范

规范版本：1.3；人工核对日期：2026-09-28；历史控制基线：primitives3_v50_20260923；新增可选 reach_pull 分支尚未完成物理成功率验证。

本文是流程、动作约束、状态字典与失败判定的统一维护入口。按实际执行顺序阅读第 1～9 节；附录从代码抽取配置与错误码，避免只描述设计意图而漏掉实现。历史验收放在 evidence/v50，不代表本地附带场景已经重跑通过。

## 1. 输入和顺序定义

两种“生成”必须区分：先生成静态场景 JSON/XML，再在已登记的场景中生成物理控制轨迹，最后回放导出数据。静态场景合格不等于任务能够完成。

输入为 XML 模板、机器人/托盘/桌子网格与碰撞形状、master seed、场景数量和配置。项目入口 `scripts/project.py`；原始生成器 `r1pro_teleop/airport_scenes.py`；正式轨迹入口 `python -m r1pro_teleop.airport_fsm`。

| 顺序 | 逻辑 | 保存/判定 |
|---|---|---|
| 1 | 枚举场景 index、seed、front_count、difficulty | 同一来源版本和 seed/attempt 对应确定性候选 |
| 2 | 采样三桌、机器人、三托盘、槽位、室内灯光 | validate_spec 静态约束 |
| 3 | 构造 XML，物理静置并规范化初始位姿 | 场景拒绝/重采样或保存 JSON/XML |
| 4 | 转换四相机，prepare 登记来源和 split | 哈希、场景数量、相机契约检查 |
| 5 | preflight 编译移动模型并静置 2 秒 | 合格才允许轨迹生成 |
| 6 | FSM 选择目标→对齐→推动或抓抬→搬运→放置→验证 | 连续物理轨迹；有限恢复；失败保留日志 |
| 7 | 三托盘全部验收，结束 Episode | physics_success 与 recovery_used 独立记录 |
| 8 | 分段、物理回放、四路编码、官方 LeRobot loader 验证 | export_quality 独立于物理成功 |
| 9 | 汇总 report、split/质量检查 | 不能以“命令返回 0”代替全部成功 |

并行 worker 的完成顺序不是 index 顺序，也不是训练数据的时间顺序。程序按 scene_id/manifest 身份跟踪，不根据日志先后推断场景编号。

## 2. 场景枚举、几何和随机化

### 2.1 枚举公式

`front_count = index % 4`，`block = index // 4`，`scene_id = airport_{index:04d}_{seed}`，每个场景 seed 为该集合 master_seed + index。内部候选 RNG 为 `SeedSequence([seed, attempt])`；拒绝后增加 attempt，不偷偷改其他场景的 seed。

smoke 共 12 个，front_count=0/1/2/3 各 3 个；index 0、5 为 complex，其余 ordinary。formal 共 400 个，各 front_count 100 个；block 属于 0、21、42、88、99 时为 complex，合计 20 复杂、380 普通。默认原始生成器 formal master_seed 是 smoke seed +10000。

**训练 split 以 prepare 为准：**smoke 8/2/2；formal 300/50/50，使用配置 split_seed 打乱排序后的唯一 scene_id。生成器旧 split 字段不等于最终训练 split。重采样次数是候选 attempt 的零起始索引，不是额外成功数量。

### 2.2 几何和坐标

- 每张桌长×宽×台面高度：1.2×0.6×0.8 m。前两张组成 2.4×0.6 m 履带；后方一张。
- 托盘名义长×宽×高：0.56×0.43×0.105 m。随机 XY、yaw；初始 roll/pitch=0。复杂场景允许提高 Z 放在另一托盘上，因此不是所有托盘都直接接触桌面。
- 履带原点 world=(0.55,0.6,0.8)，+X 从左到右，+Y 沿短边向桌内，+Z 向上。平面转换 `world_x=0.55+belt_y`、`world_y=0.6-belt_x`。
- 槽位 i=0,1,2：`x_i=0.005+0.43/2+i*(0.43+0.015)`，`y_i=0.6/2`，`yaw_belt=π/2`。第一托盘边缘离履带端约 5 mm，相邻名义间隙 15 mm；世界 Z 由桌面和托盘几何处理。
- 前后桌最近边缘距离 gap 均匀采样 1～2 m。后桌中心 world_x=0.25-gap；机器人初始 x=0.55-gap/2±0.06，y∈[-0.18,0.18]，yaw∈[-π,π]。
- 前桌按分层区段采样位置和 yaw。后桌放满三个 ordinary 托盘时，为可装入有限桌面，位置/yaw 采用窄范围扰动；不是三个完全自由的均匀 yaw。
- 重心 XY 必须落在指定桌面有效矩形内，边界保守内缩 15 mm；托盘边缘可略外伸，不能把重心悬空。ordinary 禁止托盘投影重叠。complex 的支撑链必须最终连到桌面。

### 2.3 光照与资源保留

当前 `sample()` 覆盖旧昼夜采样结果，最终固定 `indoor_bright`。四个天花板点光源，高度 3.2 m，方向 XY∈[-0.08,0.08]、Z=-1，漫反射强度∈[0.15,0.18]，环境光及 headlight 补光；只有第一个灯投影。独立 RNG `SeedSequence([seed,attempt,110])` 保持布局 RNG 不被光照改动影响。

地面与可见桌面使用同一 finish 材质，**不改变碰撞摩擦**。保留初始关节、托盘质量/摩擦和夹爪设置；生成槽位 site 只是目标标记，不能对托盘施加吸附力。

## 3. 静态场景拒绝与重采样

静态检查：schema、对象数量、桌距、front_count 一致性、重心支撑、托盘不低于桌面、ordinary 不重叠、槽位不越界、间隙非负。

物理检查：初始机器人碰撞、积分后的机器人碰撞、托盘触地、穿透超过 3 mm、重心不受桌面支撑、倾角超过 10°、托盘 body Z<0.79 m、静置后 ordinary 重叠、支撑接触链缺失、平移速度>0.03 m/s，均拒绝。**10° 是此生成阶段阈值，正式 preflight 和放置验收是 5°，不能混用。**

`generate_one` 最多进行 3 轮“静置结果回写初始 XYZ/yaw→重新生成 XML”规范化，位移收敛要求 ≤5 mm，再重新静置验证 ≤5 mm。roll/pitch 仍由 upright 参数生成。只允许修改尚未登记的候选初态，不能把该机制用于执行中移动物体。

`ValueError` 拒绝记录 `{attempt,reason}`，继续下一个候选；默认每场景最多 250 次。耗尽保存 failure.json 并抛出错误，不能用最后一个非法候选填数。非 ValueError 异常不保证进入普通重采样，应当按生成程序异常排查。

成功保存 scene.json、scene.xml、seed、scene_id、difficulty、原 split、rejections、resample_count、模板/XML 哈希与依赖版本。ordinary/complex 分目录，manifest 汇总拒绝原因。相同 seed 的复现还依赖同版本代码、资源和物理环境，不能跨版本只凭 seed 宣称逐帧一致。

## 4. 四相机、登记与正式预检

1. 四相机转换从审计读取 K 和已发布 TF，建立双头部/双腕部相机，更新来源与 XML 哈希。光学坐标映射和畸变尚未完成真机验证。
2. prepare 要求场景数与配置一致、ID 唯一且路径安全、JSON/XML 哈希一致、相机分辨率契约有效。冻结 split、配置和来源；已存在且不相同的 collection 拒绝覆盖。
3. materialize 创建移动底盘仿真模型。`base_control_available` 必须区分旧静态来源标记、当前仿真底盘可用性和真实底盘驱动可用性；本项目没有真机底盘驱动。
4. preflight 要求初始托盘位置与 JSON 最大分量误差≤2 mm，framebuffer 足够容纳原生图像；执行 guard 并静置 2 秒。
5. 静置后每托盘平移范数≤5 mm、倾角≤5°、有支撑接触且重心位于可支撑桌面区域。失败记 valid=false/failure_code，不进入动作生成。
6. 冻结代码/资产/URDF/物理包版本。生成前若依赖改变、预检缺失或 scene JSON 被改写，拒绝继续旧 collection。

预检只证明该初态满足当前检查，不证明任务可达、视频可读或仿真与真机一致。本地 resources/scenes 与历史服务器 v7 修正版不同，必须重新预检。

## 5. 任务选择与完整动作顺序

### 5.1 选择目标

首次调度在 3! 个 tray→slot 映射中最小化平面距离与角度代价，此后保持映射，从左到右检查槽位。**当前实现不是严格按“前桌最左托盘优先、前桌无托盘才去后桌”的人工规则排序**；它以固定目标槽位映射驱动。已满足位置/角度/倾角及相邻几何的托盘跳过，避免无意义重复抓放。

若目标托盘上有其他托盘，先处理可拿的上层；其目标槽位被挡则放到空闲缓冲区。若目标槽位被占，先尝试推动挡路托盘回自身槽位，否则移到缓冲区。若所有挡路托盘都被上层压住，还须检查包括当前目标在内的可操作上层，先将上层移到缓冲区，再重新调度下层；不能仅因 blocker 列表中没有顶层就判死锁。没有可操作上层仍为 destination_blocked_by_stack，没有合法缓冲区仍为 no_free_buffer。该分支不直接改写物体位姿。缓冲区通过有限候选搜索，必须完整支撑且不与其他托盘冲突；无空位则失败，不把托盘移到地面。临时 operation 的 slot=-1、temporary=true。

### 5.2 判断能否推动

目标为顶层可操作托盘，起点和终点均在前方履带支撑范围，倾角≤5°，XY距离≤0.18 m，yaw差≤15°。沿路径采样 25 个位置/方向：完整投影受桌面支撑，向内建立最多4 mm边界余量，与其他托盘保留2 mm规划间距。几何通过后仍需找到单侧可用边、IK和真实接触；几何可推动不等于执行必然成功。

不满足推动条件则走双臂抓取路径。初始抓取候选最多12个，每次 IK 最多160轮；笛卡尔插值出现 ik_branch_jump 时，仅在规划内对该区间二分、最多4层，仍保持原关节分支差和位姿精度限值；整段规划通过才执行，失败不执行半段路径。成功细分记录 cartesian_branch_subdivision 事件，不是物理动作事件。有限候选调整不是运行中瞬移，也不等同于整段恢复重试。

### 5.3 对齐、接近、夹持

#### 有界DAG与预抓取拉近分支（新增，显式开启）

任务规划表示为DAG，底层运动节点仍由反馈FSM执行。反复整理/恢复通过 operation/retry 编号展开为不同节点，不在DAG上画回边；每个Episode保存 task_dag.json。实际state_transition记录单调递增dag_node_id和dag_predecessor，真实执行日志是无环事件链。task_dag是条件流程契约，不是替代MuJoCo守卫的独立执行器，也不是声称已把所有内部控制循环改成无反馈控制。

```mermaid
flowchart TD
 A[选择目标并导航到候选底盘位置] --> B[肩部到左右抓取点距离估计]
 B -->|双臂预计可达| C[正常双臂抓取规划]
 B -->|双臂风险 且单臂可能可达| D[检查朝机器人拉近的完整桌面扫掠]
 D -->|不安全或单臂IK不通过| C
 D -->|通过| E[单臂真实夹持并拉近]
 E --> F[实际进展 支撑 接触检查]
 F -->|通过| G[原接触臂保持 另一臂IK再验证]
 G -->|通过| H[另一臂加入 双臂抬升]
 C --> H
 F -->|不通过| X[该attempt失败]
 G -->|不通过| X
 H --> I[搬运 放置 推调 验收]
 I --> J[完成 或下一个编号的operation]
```

使用 `configs/airport_reach_pull.json` 才开启，原 airport_primitives3.json 默认关闭，不能用旧collection继续新代码。参数：双臂启发式半径0.65m、单臂候选半径0.78m；取实际肩关节世界锚点到对应抓取点的3D距离，因此包含桌高、底盘距离、yaw和夹边方位影响。它们是工程筛选参数，不是真机可达域标定；距离通过仍必须做IK、完整路径和接触验证，距离不通过也不等于严格数学不可达证明。

每只托盘每Episode最多执行一次拉近，预估条件为至少一侧超过双臂半径、至少一只手在单臂候选半径内，预计最差双臂距离改善超过5mm。默认沿托盘→机器人平面方向拉8cm；按4个递减候选缩短到最小2cm，选首个安全扫掠。整个托盘投影必须在同一张桌面内，保留5mm边界，每条路径采样25点、邻盘间距2mm；必须顶层且直接桌面支撑，禁止把堆叠上层拖过下层。

选中手先单独预览高位和夹边IK，绕过“必须先双臂都可达才能单臂调整”的旧前置条件。实际动作复用固定时间的单边接触平移primitive，不直接设置托盘pose。真实位移沿目标方向至少2cm、实际终点投影仍在桌内，并通过已有接触/相机/碰撞守卫后，保留接触侧，验证另一臂能否加入；失败不可恢复，不能重复拉动或强行抓取。单原语≤3秒，但建接触和后续再评估不计入该平移原语预算。

新增状态日志 phase=`pull`，state仍为ADJUST_TRAY，skill=`push_adjust_tray`、primary_class=`adjust`保持旧数据兼容。reach_assessment、reach_pull_skipped、reach_pull_candidate_rejected、reach_pull_started、reach_pull_completed记录决策/实际进展，不能把这些控制日志当成接触证据。新增失败码包括 reach_pull_sweep_invalid、reach_pull_progress_or_support_failed、reach_pull_failed；外层可能包装为 contact_handoff_aborted，原原因保留detail。

底盘先规划到可达位置，机械臂按直接夹边模板接近；检查关节/碰撞/腕部相机，不通过时尝试其他候选。当前夹爪张开命令0.10 m、闭合目标0 m，闭合受接触和执行器力限制，不代表实体夹爪可以穿过托盘。

先 pregrasp，再 approach、contact、close、load_transfer。双侧夹爪与目标托盘接触力均>0.5 N 是夹持证据之一；只有闭合命令不算夹住。调整→拿起时保留原接触侧，另一臂加入，不能先双臂撤离再重抓。无双侧接触、另一臂无可用路径或衔接对象不一致，均失败。

### 5.4 固定抬升 lift

名义向上命令0.18 m。先规划纯垂直路径；不可行时依次试沿朝底盘方向的有符号平移0、+2、-2、+4、-4、+6、-6 cm，非零平移可补偿最多2 cm高度，均在执行前校验。不是逐个真实试抓。

完整连续路径必须满足动力学、关节、相机、碰撞及夹持关系约束，并留出配置0.1秒末端验证预算，总 primitive≤3秒。不允许超时后切回隐藏慢速轨迹。

**当前代码的精确高度定义：**`height = 当前托盘 min_z - 本次 lift 开始时 min_z`，验收0.15～0.20 m，同时无支撑接触、双侧力>0.5 N、倾角≤5°。这是相对抬升增量；起点在桌面上时近似离桌高度，起点为堆叠上层时不能等同于绝对离桌高度。旧简述中的“实际离桌15～20cm”在堆叠情形不够精确，以此定义为准。若未来要求绝对桌面净空，应修改代码和本文并新增堆叠测试。

`lift_above_2cm` 是后处理事件阈值，不能代替15～20cm的动作验收。

### 5.5 搬运与放置 place

搬运期间保留双侧受力，导航改变底盘目标而非直接移动托盘。底盘候选路径除命令参考运动学检查外，还把实测托盘位置/姿态随候选底盘变换，检查独立 shadow 中的载荷扫掠；对非机器人碰撞物加入15mm规划余量，以覆盖夹持受力偏移。此为规划近似，不是动态无碰撞保证，执行仍受原接触守卫约束，不修改 live qpos。运输状态发现重新碰到支撑物、长时间失去双侧接触或夹起其他托盘即失败。

按目标桌高、托盘碰撞网格最低点和间距计算放置姿态。为避开邻盘可能先放 staging 位置再推动。普通末端XY对齐是独立的≤3秒动作；边缘工作空间可将水平回收和下降合并到一次 place。

放置顺序：transport→preplace→descend→support_contact→unload→open→retreat（某些细分标签在固定分支会合并或没有单独采样帧，不强行补造）。只有检测到真实桌面支撑才可开爪。固定下降结束未接触时，不再只等待固定0.1秒；将3秒原语剩余帧扣除完整释放路径帧数后，逐帧等待接触，首次真实接触即继续释放。预算耗尽仍无接触报 primitive_touchdown_not_observed，不开爪、不增加动作预算。需要后续推动时释放一侧并避让，另一侧继续夹持；最终是否摆好必须在释放后的稳定阶段检查。

下降与受控释放共享3秒预算；2cm释放间隙和3mm touchdown preload 是指令参数，不能解释为允许额外实体穿透。无法在预算内找到路径、无桌面承重或释放未被观测到，都失败。

### 5.6 固定推动 push

无已有接触时先找到单侧可用边并建立接触；已有放置/分离衔接时验证 tray/side 一致再复用。接触手推进/转向，释放手避让，规划整段连续路径，不逐路点停稳。

推动根据碰撞网格最低点和目标姿态计算支撑高度，普通推动命令向下预压最多1mm，边缘撤手分支沿用原4.5mm预压且不叠加。预压只是位置伺服目标，真实穿透与支撑守卫不变；primitive_push_support_height记录目标高度。

推动允许有受限指令前馈补偿：配置35mm，分离或边缘分支使用更小值；不能以命令到位替代物体实际到位。边缘分支可能采用4.5mm法向指令预压，但实际穿透守卫仍为3mm。执行中保持桌面支撑、接触侧受力和自由侧脱离，衔接失败立即终止，不能隐藏重抓。

动作终点核对位置/yaw等，再释放并做最终间隙验收，避免夹持弹性偏转导致重复抓放。固定模式的 accuracy/placement错误通常不可恢复；详见错误码调用点，而不是见到错误一律再试。

### 5.7 验证、重复或结束

每次操作后核对实际位置、方向、支撑和释放证据；全部槽位满足后还要通过全任务尾部稳定窗口。通过则 TASK_COMPLETE；否则选择下一目标或有限修正。已有最终物理验收通过时优先结束，不因规划余量不同重新拿起已完成托盘。

## 6. 时间、安全与成功判定

| 项目 | 当前规则 |
|---|---|
| 控制频率 | 20 Hz，记录 state[t] 后施加 action[t]，保持一个控制周期 |
| 单 primitive | ≤3秒控制/仿真时间；不是 CPU 求解墙钟时间 |
| 3秒不包含 | 初始抓取、底盘导航、推动后的松爪退出、最终1秒稳定检查；普通末端对齐另有预算 |
| 每场景 attempt | 最多6次；每次有独立seed/目录，不在单Episode内重置物理 |
| 单operation局部尝试 | 最多3次，且仅 recoverable 错误允许恢复 |
| 单Episode | 最多18次operation、600秒仿真时间、1800秒墙钟预算；通用phase预算45秒 |
| 最终位置/yaw/倾角 | ≤3cm / ≤5° / ≤5°；角度周期按显式对称性配置 |
| 相邻间隙 | 0～3cm，不用托盘中心距离直接代替边缘间距 |
| 最终稳定 | ≥1秒、速度≤0.01m/s；20Hz最终窗口至少21帧 |
| 穿透 | >3mm失败；非法接触对象另受更严格碰撞规则约束 |
| 双侧接触丢失 | holding 中任一侧力≤0.5N持续>0.12秒失败 |
| 运输倾角守卫 | holding 中>20°失败；最终验收仍≤5° |
| 实测超速 | 机械臂>参考实际速度帽1.01倍失败；底盘同样有实测速度上限 |

任何 NaN/Inf、新增 MuJoCo warning、非法碰撞、触地、穿透、违反手腕相机朝向、额外托盘被抬起、动力学/力矩/功率帽超限，均不能进入成功训练集。model80 是现有工程/URDF参数，不是实测真机80%最大功率。逆动力学用于参考可行性与时间参数化；实际执行是限力位置伺服，并非通过逆动力学直接给物体指定轨迹。

其中45秒由相关关节/路径执行接口检查，不是对每个FSM状态设置了独立全局45秒计时器。单侧保留接触另有受限桌面接触宽限：仅在几何间隙[-3,+2]mm且缺失≤0.15秒时容许瞬时接触列表抖动，仍要求接触手力>0.5N和闭合命令；不是无限容忍悬空。

最终验收既检查尾部稳定，也检查整个Episode是否出现落地、非法碰撞、穿透、相机违规、不完整控制区间等。末帧看起来整齐不能抹去中途违规。

## 7. 状态、技能、phase、事件和结果字典

### 7.1 FSM状态字典（不是结果状态）

| state | 含义/主要逻辑 | skill | primary_class |
|---|---|---|---|
| SEARCH_TARGET | 选择下一目标/槽位，处理遮挡与缓冲区 | verify_or_recover | null |
| ALIGN_BASE | 移动并对齐仿真底盘 | navigate_to_tray | null |
| APPROACH_TRAY | 夹爪接近可操作边或接触衔接 | grasp_lift_tray | pick |
| ADJUST_TRAY | 桌面推动/转向以及相关夹持释放 | push_adjust_tray | adjust |
| GRASP_TRAY | 双侧接触、闭合、承重、抬升、稳定 | grasp_lift_tray | pick |
| TRANSPORT_TRAY | 携托盘运输 | carry_tray | place |
| PLACE_TRAY | 下降、承重、释放、撤离 | place_release_tray | place |
| VERIFY_PLACEMENT | 检查释放后的摆放和稳定性 | verify_or_recover | null |
| RECOVER | 有限安全恢复；不是重新初始化Episode | verify_or_recover | null |
| TASK_COMPLETE | 全任务物理验收已通过 | verify_or_recover | null |

注意 FSM 状态在 trace 中叫 `fsm_state`；同一 trace 中 `state` 是16维关节/夹爪观测，不能混淆。

字段单位：关节角/yaw 为 rad，长度和夹爪开口为 m，接触力为 N，时间为 s。MuJoCo/托盘pose四元数为 wxyz，审计发布的TF可能标为xyzw，转换必须显式处理。目标tray/slot在trace里是整数索引，-1表示未分配/临时目标；segment中转换为字符串ID或null，不能把-1当成最后一个槽位。

### 7.2 phase字典

| phase | 含义 |
|---|---|
| unknown | 该状态没有更细粒度阶段标签；不是“成功” |
| pregrasp / approach | 抓取前准备 / 接近边缘 |
| contact / close / load_transfer | 接触 / 闭合 / 承重转移 |
| lift / stabilize | 抬升 / 抬升后稳定 |
| transport / preplace / descend | 搬运 / 放置前准备 / 下降 |
| support_contact / unload / open / retreat | 支撑接触 / 卸载 / 开爪 / 撤离 |
| adjust | 桌面推动或方向调整 |
| pull | 可选预抓取拉近，与adjust采用相同接触/移动证据复核 |
| verified | 进入检查或完成相关状态；标签本身不是成功证据 |
| recover | 恢复阶段，必须needs_review |

同名phase可用于不同状态，必须联合state解释。phase来源是控制意图，接触证据另行验证；固定动作分支可能跳过或合并标签，不能人工填出不存在的帧。

### 7.3 自动检测事件

| event | 当前检测逻辑/限制 |
|---|---|
| gripper_contact | 任一夹爪力>0.5N出现边沿 |
| bilateral_grasp_observed | 双侧力>0.5N且双夹爪观测开口<0.035m，在双侧接触上升沿检测 |
| lift_above_2cm | 无支撑、相对Episode首帧min_z增量>0.02m、双侧接触 |
| table_support_restored | 曾抬起后，直接桌面接触由无变有 |
| bilateral_contact_loss_in_air | 上一帧双侧接触、本帧非双侧且无支撑 |
| open_release | 夹爪接触消失、有支撑且双开口>0.06m；单侧衔接不一定触发 |
| dropped_to_floor | 首次触地边沿 |
| table_push_or_rotate | 桌面支撑+夹爪接触，XY速度超过0.015m/s的上升沿；当前不独立检测原地纯旋转 |
| incomplete_control_interval | 当前控制周期未完成，关联失败原因 |
| task_complete_physically_verified | Episode物理成功后的末帧事件 |

独立“重抓”事件和独立“槽位稳定1秒”事件不是此后处理函数的完整输出；重抓看状态/控制日志，稳定看最终验收。不要把设计要求当作已有独立事件。`events.jsonl` 还含操作选择、transition、primitive起止、候选拒绝等控制日志，与接触证据事件区别使用。

### 7.4 场景覆盖/导出结果状态

| status/字段 | 含义 |
|---|---|
| not_attempted | 尚无执行result；不能当失败或成功 |
| preflight_rejected | 初态预检不合格 |
| attempted_failed | 已尝试但无合格完整成功 |
| recovery_only | 有物理成功但使用过恢复；不进普通BC成功集 |
| physics_ready | 无恢复的物理成功达到数量要求且未被导出拒绝；不等于已导出 |
| export_quality_rejected | 物理候选被导出质量检查拒绝 |
| export_quality.status=accepted/rejected | 导出校验结果，独立文件字段 |
| physics_success | 完整任务物理验收结果 |
| training_candidate | 物理成功且无恢复的候选资格，仍须通过导出质量门 |
| needs_review | 当前片段证据不足或处于恢复，不猜标签 |

覆盖状态按 registry.coverage 的优先顺序计算，不是严格单向生命周期；同场景可能存在多个失败和成功attempt。`exported_scene_count` 才体现导出覆盖；要求全部通过需使用 report 的 require 参数。

## 8. 失败分层与重试规则

| 层 | 典型失败码/原因 | 下一步 |
|---|---|---|
| 生成候选 | com_outside_table、ordinary_overlap、no_support_contact_chain、settle_pose_drift | 记录拒绝原因，在预算内换候选 |
| 来源/预检 | source_xml_checksum_mismatch、scene_preflight_missing、initial_scene_settle_drift、initial_tray_has_no_support | 停止该来源；修正新场景版本后重新登记预检 |
| 几何调度 | no_free_buffer、cyclic_or_unresolved_stack、destination_blocked_by_stack | 该attempt失败，不能伪造空位 |
| 抓取/IK | ik_unreachable、no_feasible_grasp_approach、no_free_single_rim、missing_bilateral_contact | 仅在具体Fault允许recoverable且有安全支撑时有限恢复 |
| 固定原语 | primitive_path_infeasible、primitive_lift_path_unavailable、primitive_deadline_exceeded | 原语上下文将Fault转不可恢复；失败而非超时后慢速继续 |
| 接触衔接 | contact_handoff_aborted、retained contact相关故障 | 保留接触时不能直接撤回重抓，终止attempt |
| 物理安全 | illegal_collision、tray_on_floor、excess_penetration、bilateral_contact_lost、wrist_camera_front_guard | 终止并保留完整证据 |
| 时间/次数 | episode_budget_exhausted、operation_budget_exhausted、worker timeout/crash | 记录失败/进程日志，受场景attempt预算限制 |
| 导出 | replay_diverged、loader_native_resolution、scene_split_leak等 | 隔离失败导出，不能发布为成功训练数据 |

`recoverable` 是具体调用点的属性，不是同名错误码全局固定属性；嵌套primitive/接触衔接可以把可恢复错误改为不可恢复。恢复只能从当前物理状态做动作，不能重置qpos。整个attempt重新开始必须新建Episode，保留先前失败。

附录收录静态字符串Fault/ValueError/事件与调用位置，供定位代码；动态拼接、依赖库异常、worker包装错误仍需看 result.error、events和日志，不能声称附录覆盖一切异常。

## 9. 记录、分段、导出与完成标准

raw Episode是唯一源。每帧记录时间戳、16维双臂状态/动作、独立base状态/动作、仿真积分状态、目标tray/slot、phase、recovery及privileged接触/pose。先记录观测再执行动作；末端快照验证完整回放。20Hz动作不可与变速视频错配。

按 `(fsm_state, phase, tray, slot, recovery)` 变化切片，区间 `[start_frame,end_frame)`。包含episode_id、scene_id、split、skill、phase、primary_class、目标tray/slot、success、recovery、failure_reason、needs_review、来源和注释版本。

当前 lift/stabilize/transport 片段要求**每帧**双侧接触且无支撑，否则needs_review；support_contact要求至少观测到桌面接触；adjust要求片段XY净移动>1mm并观测到接触，否则needs_review（纯旋转可能需人工/后续规则复核）。RECOVER始终needs_review。成功片段还依赖整个Episode成功，不能从失败Episode中自动挑出“成功标签”。

四路原生视频：双头部1920×1536、双腕部1280×720，20fps，H.264 CRF18，不裁剪/缩放/变速/贴字。以官方LeRobot 0.4.4 API导出，loader读每Episode首末帧，检查帧数、分辨率、回放误差、空白帧和scene泄漏。16维 legacy16与19维 mobile19分开标记；额外3维为仿真底盘绝对目标，不是真机cmd_vel。

adjust/pick/place/full_arrangement视图只引用原Episode，不复制视频。来源严格为 program_generated + simulation；privileged真值不能伪装成部署观察。训练统计/归一化只用train，所有同scene片段和attempt留在同split。

完成判定分四级：**场景生成合格 → preflight合格 → 完整物理任务成功 → LeRobot验收通过**。要求400场景全部完成时，四级必须逐场景满足，拒绝/未尝试/仅恢复成功不算普通成功覆盖。

## 10. 维护方式与变更记录

修改场景、配置、FSM、接触判定、相机、标注或导出时，在**同一次改动**更新本文相应步骤、阈值、字典、失败/恢复逻辑及变更记录；同时运行 `python scripts/sync_task_spec.py --write` 更新附录，再运行 `python scripts/sync_task_spec.py --check`。检查器记录相关代码哈希，代码变而本文附录未更新会失败；自动附录不代替人工核对逻辑。

这是修改代码时同步维护的约定，不是后台监控服务。README/其他文档作为入口和补充，涉及规则冲突时先核对实现并修订本文，不能静默保留两份不同阈值。

| 日期 | 版本 | 改动/验证 |
|---|---|---|
| 2026-09-24 | 1.0 | 按当前代码建立完整顺序、状态/phase/事件/结果字典；明确相对lift高度、实际调度顺序、明亮室内灯光、事件检测限制；控制代码未改 |
| 2026-09-24 | 1.1 | 增加有界任务DAG和单臂拉近启发式分支；新配置显式开启；几何/控制流回归测试与模型接口核验，不代表物理拉近成功率或已部署服务器 |

| 2026-09-28 | 1.2 | 修复目标托盘本身位于目标槽位挡路托盘之上的调度死锁；沿用支撑/缓冲区/物理守卫，增加不改写场景及无缓冲区拒绝测试；增加实测载荷扫掠及15mm规划避障余量、规划区间有限二分；候选内抓取预览v5实验导致基准场景4回归，未采用；服务器物理验证待完成 |

| 2026-09-28 | 1.3 | 依据400首轮22成功/378失败，增加剩余预算内触桌等待及网格支撑高度预压；测试与新release实测分别记录，不混用历史验收 |

<!-- GENERATED-CONTRACT:START -->
## 附录：当前实现字典与配置快照（自动维护）

由 scripts/sync_task_spec.py 生成。错误码表覆盖静态调用点；同名码可有不同恢复属性，实际还受上下文覆盖。

### FSM枚举

`SEARCH_TARGET`、`ALIGN_BASE`、`APPROACH_TRAY`、`ADJUST_TRAY`、`GRASP_TRAY`、`TRANSPORT_TRAY`、`PLACE_TRAY`、`VERIFY_PLACEMENT`、`RECOVER`、`TASK_COMPLETE`

### 实际transition调用的phase

- `adjust`：`r1pro_teleop/airport_fsm/machine.py:547`
- `approach`：`r1pro_teleop/airport_fsm/machine.py:183`；`r1pro_teleop/airport_fsm/machine.py:521`
- `close`：`r1pro_teleop/airport_fsm/machine.py:209`；`r1pro_teleop/airport_fsm/machine.py:532`
- `contact`：`r1pro_teleop/airport_fsm/machine.py:207`
- `descend`：`r1pro_teleop/airport_fsm/machine.py:416`；`r1pro_teleop/airport_fsm/primitives.py:239`；`r1pro_teleop/airport_fsm/primitives.py:272`
- `lift`：`r1pro_teleop/airport_fsm/machine.py:232`；`r1pro_teleop/airport_fsm/machine.py:365`；`r1pro_teleop/airport_fsm/primitives.py:171`
- `load_transfer`：`r1pro_teleop/airport_fsm/machine.py:218`
- `open`：`r1pro_teleop/airport_fsm/machine.py:429`；`r1pro_teleop/airport_fsm/machine.py:473`；`r1pro_teleop/airport_fsm/machine.py:663`；`r1pro_teleop/airport_fsm/primitives.py:289`
- `pregrasp`：`r1pro_teleop/airport_fsm/machine.py:136`
- `preplace`：`r1pro_teleop/airport_fsm/machine.py:387`；`r1pro_teleop/airport_fsm/primitives.py:234`
- `pull`：`r1pro_teleop/airport_fsm/machine.py:547`
- `recover`：`r1pro_teleop/airport_fsm/machine.py:771`
- `retreat`：`r1pro_teleop/airport_fsm/machine.py:476`；`r1pro_teleop/airport_fsm/machine.py:482`
- `stabilize`：`r1pro_teleop/airport_fsm/machine.py:264`；`r1pro_teleop/airport_fsm/primitives.py:197`
- `support_contact`：`r1pro_teleop/airport_fsm/machine.py:418`；`r1pro_teleop/airport_fsm/primitives.py:274`
- `transport`：`r1pro_teleop/airport_fsm/machine.py:333`
- `unknown`：`r1pro_teleop/airport_fsm/machine.py:115`；`r1pro_teleop/airport_fsm/machine.py:148`；`r1pro_teleop/airport_fsm/machine.py:50`；`r1pro_teleop/airport_fsm/machine.py:813`；`r1pro_teleop/airport_fsm/machine.py:822`
- `unload`：`r1pro_teleop/airport_fsm/machine.py:421`
- `verified`：`r1pro_teleop/airport_fsm/machine.py:748`；`r1pro_teleop/airport_fsm/machine.py:830`；`r1pro_teleop/airport_fsm/machine.py:834`；`r1pro_teleop/airport_fsm/machine.py:838`

### 证据事件emit字典

- `bilateral_contact_loss_in_air`：`r1pro_teleop/airport_fsm/trace.py:164`
- `bilateral_grasp_observed`：`r1pro_teleop/airport_fsm/trace.py:160`
- `dropped_to_floor`：`r1pro_teleop/airport_fsm/trace.py:166`
- `gripper_contact`：`r1pro_teleop/airport_fsm/trace.py:159`
- `incomplete_control_interval`：`r1pro_teleop/airport_fsm/trace.py:169`
- `lift_above_2cm`：`r1pro_teleop/airport_fsm/trace.py:162`
- `open_release`：`r1pro_teleop/airport_fsm/trace.py:165`
- `table_push_or_rotate`：`r1pro_teleop/airport_fsm/trace.py:168`
- `table_support_restored`：`r1pro_teleop/airport_fsm/trace.py:163`
- `task_complete_physically_verified`：`r1pro_teleop/airport_fsm/trace.py:170`

### 静态错误码与具体恢复声明

| 错误码 | 调用位置及 recoverable 声明 |
|---|---|
| `action_dtype_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:55` → `False` |
| `action_shape_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:54` → `False` |
| `airborne_separation_clearance_not_met` | `r1pro_teleop/airport_fsm/machine.py:291` → `True` |
| `airborne_separation_direction_ambiguous` | `r1pro_teleop/airport_fsm/machine.py:281` → `True` |
| `aisle_gap` | `r1pro_teleop/airport_scenes.py:56` → `生成器捕获ValueError时重采样` |
| `asset_changed_since_preflight` | `r1pro_teleop/airport_fsm/batch.py:99` → `False` |
| `asset_missing` | `r1pro_teleop/airport_fsm/batch.py:58` → `False` |
| `attempt_index_out_of_budget` | `r1pro_teleop/airport_fsm/__main__.py:75` → `False` |
| `attempt_to_grasp_lower_stacked_tray` | `r1pro_teleop/airport_fsm/machine.py:712` → `False` |
| `base_tracking_error` | `r1pro_teleop/airport_fsm/runtime.py:1175` → `True` |
| `batch_cancelled` | `r1pro_teleop/airport_fsm/batch.py:164` → `False` |
| `batch_lock_requires_posix` | `r1pro_teleop/airport_fsm/__main__.py:24` → `False` |
| `bilateral_contact_lost` | `r1pro_teleop/airport_fsm/runtime.py:345` → `False` |
| `blended_path_joint_limit` | `r1pro_teleop/airport_fsm/runtime.py:874` → `True`<br>`r1pro_teleop/airport_fsm/runtime.py:892` → `True` |
| `camera_contract_mismatch` | `r1pro_teleop/airport_fsm/registry.py:40` → `False`<br>`r1pro_teleop/airport_fsm/registry.py:44` → `False` |
| `camera_low_texture_needs_review` | `r1pro_teleop/airport_fsm/exporter.py:105` → `False` |
| `carried_payload_support_contact` | `r1pro_teleop/airport_fsm/runtime.py:336` → `False` |
| `carried_tray_tilt` | `r1pro_teleop/airport_fsm/runtime.py:348` → `False` |
| `cartesian_collision_or_wrist` | `r1pro_teleop/airport_fsm/runtime.py:797` → `True` |
| `catalog_artifact_missing_or_size_changed` | `r1pro_teleop/airport_fsm/registry.py:182` → `False` |
| `catalog_shard_missing` | `r1pro_teleop/airport_fsm/registry.py:179` → `False` |
| `collection_already_in_use` | `r1pro_teleop/airport_fsm/__main__.py:22` → `False` |
| `collection_scene_changed` | `r1pro_teleop/airport_fsm/registry.py:112` → `False` |
| `com_outside_table` | `r1pro_teleop/airport_scenes.py:60` → `生成器捕获ValueError时重采样` |
| `com_unsupported` | `r1pro_teleop/airport_scenes.py:200` → `生成器捕获ValueError时重采样` |
| `configured_limit_profile_changed` | `r1pro_teleop/airport_fsm/batch.py:91` → `False` |
| `configured_urdf_missing` | `r1pro_teleop/airport_fsm/runtime.py:143` → `False` |
| `contact_handoff_aborted` | `r1pro_teleop/airport_fsm/machine.py:871` → `False` |
| `controller_code_changed_since_preflight` | `r1pro_teleop/airport_fsm/batch.py:86` → `False` |
| `coupled_ik_unreachable` | `r1pro_teleop/airport_fsm/runtime.py:631` → `True` |
| `cyclic_or_unresolved_stack` | `r1pro_teleop/airport_fsm/geometry.py:243` → `False` |
| `dataset_artifact_checksum_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:308` → `False` |
| `dataset_path_escape` | `r1pro_teleop/airport_fsm/exporter.py:303` → `False` |
| `dataset_split_leak` | `r1pro_teleop/airport_fsm/registry.py:187` → `False` |
| `dataset_symlink_target_changed` | `r1pro_teleop/airport_fsm/loading.py:33` → `False` |
| `dependencies_changed` | `r1pro_teleop/airport_fsm/batch.py:76` → `False` |
| `destination_blocked_by_stack` | `r1pro_teleop/airport_fsm/geometry.py:266` → `False` |
| `direct_grasp_closure_blocked` | `r1pro_teleop/airport_fsm/machine.py:165` → `True` |
| `duplicate_tray_id` | `r1pro_teleop/airport_fsm/geometry.py:99` → `False` |
| `encoded_frame_count_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:219` → `False` |
| `encoded_video_camera_unknown` | `r1pro_teleop/airport_fsm/exporter.py:140` → `False` |
| `encoded_video_contract_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:143` → `False` |
| `episode_budget_exhausted` | `r1pro_teleop/airport_fsm/runtime.py:362` → `False` |
| `excess_penetration` | `r1pro_teleop/airport_fsm/runtime.py:311` → `False` |
| `export_task_revalidation_failed` | `r1pro_teleop/airport_fsm/exporter.py:63` → `False` |
| `final_physical_acceptance_failed` | `r1pro_teleop/airport_fsm/machine.py:845` → `False` |
| `framebuffer_smaller_than_native_contract` | `r1pro_teleop/airport_fsm/batch.py:114` → `False` |
| `front_count` | `r1pro_teleop/airport_scenes.py:57` → `生成器捕获ValueError时重采样` |
| `handoff_carry_clearance_unreachable` | `r1pro_teleop/airport_fsm/machine.py:309` → `False` |
| `handoff_lift_contact_lost` | `r1pro_teleop/airport_fsm/machine.py:300` → `False` |
| `hardware_profile_unverified` | `r1pro_teleop/airport_fsm/runtime.py:167` → `False` |
| `ik_branch_jump` | `r1pro_teleop/airport_fsm/runtime.py:579` → `True` |
| `ik_unreachable` | `r1pro_teleop/airport_fsm/runtime.py:577` → `True` |
| `illegal_collision` | `r1pro_teleop/airport_fsm/runtime.py:306` → `False` |
| `illegal_penetration` | `r1pro_teleop/airport_scenes.py:197` → `生成器捕获ValueError时重采样` |
| `incompatible_power_definition` | `r1pro_teleop/airport_fsm/runtime.py:169` → `False` |
| `incomplete_control_interval` | `r1pro_teleop/airport_fsm/exporter.py:112` → `False`<br>`r1pro_teleop/airport_fsm/exporter.py:53` → `False` |
| `incomplete_scene_materialization` | `r1pro_teleop/airport_fsm/registry.py:118` → `False` |
| `incomplete_urdf_limits` | `r1pro_teleop/airport_fsm/runtime.py:156` → `False` |
| `initial_com_not_supported` | `r1pro_teleop/airport_fsm/batch.py:131` → `False` |
| `initial_pose_disagrees_with_scene_json` | `r1pro_teleop/airport_fsm/batch.py:110` → `False` |
| `initial_scene_settle_drift` | `r1pro_teleop/airport_fsm/batch.py:121` → `False` |
| `initial_scene_settle_tilt` | `r1pro_teleop/airport_fsm/batch.py:126` → `False` |
| `initial_tray_has_no_support` | `r1pro_teleop/airport_fsm/batch.py:129` → `False` |
| `interrupted` | `r1pro_teleop/airport_fsm/machine.py:918` → `False` |
| `invalid_action_target` | `r1pro_teleop/airport_fsm/runtime.py:690` → `False` |
| `invalid_belt_rotation` | `r1pro_teleop/airport_fsm/geometry.py:103` → `False` |
| `invalid_diagnostic_attempt` | `r1pro_teleop/airport_fsm/__main__.py:90` → `False` |
| `invalid_gripper_contact_sides` | `r1pro_teleop/airport_fsm/runtime.py:753` → `False` |
| `invalid_gripper_contact_target` | `r1pro_teleop/airport_fsm/runtime.py:750` → `False` |
| `invalid_gripper_units_or_opening` | `r1pro_teleop/airport_fsm/exporter.py:60` → `False` |
| `invalid_hardware_limits` | `r1pro_teleop/airport_fsm/runtime.py:173` → `False` |
| `invalid_or_duplicate_shard_repo_id` | `r1pro_teleop/airport_fsm/loading.py:27` → `False` |
| `invalid_quaternion` | `r1pro_teleop/airport_fsm/geometry.py:49` → `False` |
| `invalid_retained_push_contact` | `r1pro_teleop/airport_fsm/machine.py:540` → `False` |
| `inverse_dynamics_infeasible` | `r1pro_teleop/airport_fsm/runtime.py:726` → `True`<br>`r1pro_teleop/airport_fsm/runtime.py:927` → `True` |
| `joining_arm_path_unavailable` | `r1pro_teleop/airport_fsm/machine.py:200` → `False` |
| `joint_or_gripper_limit` | `r1pro_teleop/airport_fsm/runtime.py:695` → `False` |
| `joint_path_collision_or_wrist` | `r1pro_teleop/airport_fsm/runtime.py:707` → `True` |
| `joint_tracking_error` | `r1pro_teleop/airport_fsm/runtime.py:737` → `False`<br>`r1pro_teleop/airport_fsm/runtime.py:942` → `False` |
| `lerobot_frame_count_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:209` → `False` |
| `lerobot_version_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:261` → `False` |
| `loader_action_shape` | `r1pro_teleop/airport_fsm/exporter.py:213` → `False` |
| `loader_native_resolution` | `r1pro_teleop/airport_fsm/exporter.py:216` → `False` |
| `local_retry_budget_exhausted` | `r1pro_teleop/airport_fsm/machine.py:878` → `False` |
| `manifest_path_escape` | `r1pro_teleop/airport_fsm/registry.py:28` → `False` |
| `manifest_scene_identity_mismatch` | `r1pro_teleop/airport_fsm/registry.py:34` → `False` |
| `materialized_scene_json_changed` | `r1pro_teleop/airport_fsm/batch.py:97` → `False` |
| `measured_base_overspeed` | `r1pro_teleop/airport_fsm/runtime.py:328` → `False` |
| `measured_joint_overspeed` | `r1pro_teleop/airport_fsm/runtime.py:323` → `False` |
| `mechanical_power_cap` | `r1pro_teleop/airport_fsm/runtime.py:332` → `False` |
| `missing_actuated_sim_base` | `r1pro_teleop/airport_fsm/runtime.py:65` → `False` |
| `missing_bilateral_contact` | `r1pro_teleop/airport_fsm/machine.py:213` → `True` |
| `missing_dataset_checksums` | `r1pro_teleop/airport_fsm/exporter.py:310` → `False` |
| `missing_native_camera` | `r1pro_teleop/airport_fsm/runtime.py:120` → `False` |
| `missing_shard_directory` | `r1pro_teleop/airport_fsm/loading.py:30` → `False` |
| `missing_tray_collision_vertices` | `r1pro_teleop/airport_fsm/runtime.py:72` → `False` |
| `missing_wrist_camera_body` | `r1pro_teleop/airport_fsm/runtime.py:123` → `False` |
| `mixed_action_layout` | `r1pro_teleop/airport_fsm/exporter.py:265` → `False` |
| `mixed_camera_contract_shard` | `r1pro_teleop/airport_fsm/exporter.py:172` → `False` |
| `mixed_split_shard` | `r1pro_teleop/airport_fsm/exporter.py:156` → `False` |
| `mujoco_not_installed` | `r1pro_teleop/airport_fsm/batch.py:187` → `False` |
| `mujoco_warning` | `r1pro_teleop/airport_fsm/runtime.py:303` → `False` |
| `multiple_trays_lifted` | `r1pro_teleop/airport_fsm/runtime.py:351` → `False` |
| `negative_slot_gap` | `r1pro_teleop/airport_scenes.py:69` → `生成器捕获ValueError时重采样` |
| `nested_primitive` | `r1pro_teleop/airport_fsm/primitives.py:21` → `False` |
| `no_collision_free_base_route` | `r1pro_teleop/airport_fsm/runtime.py:1140` → `True` |
| `no_encoded_videos` | `r1pro_teleop/airport_fsm/exporter.py:148` → `False` |
| `no_exported_shards_for_split` | `r1pro_teleop/airport_fsm/loading.py:20` → `False` |
| `no_feasible_grasp_approach` | `r1pro_teleop/airport_fsm/machine.py:149` → `True` |
| `no_free_buffer` | `r1pro_teleop/airport_fsm/geometry.py:192` → `False` |
| `no_free_single_rim` | `r1pro_teleop/airport_fsm/machine.py:530` → `True` |
| `no_safe_release_clearance` | `r1pro_teleop/airport_fsm/machine.py:327` → `True` |
| `no_support_before_release` | `r1pro_teleop/airport_fsm/machine.py:420` → `True` |
| `no_support_contact_chain` | `r1pro_teleop/airport_scenes.py:225` → `生成器捕获ValueError时重采样` |
| `no_supported_airborne_recovery` | `r1pro_teleop/airport_fsm/machine.py:787` → `False` |
| `no_unambiguous_supported_table` | `r1pro_teleop/airport_fsm/machine.py:75` → `False` |
| `nonfinite_inverse_dynamics` | `r1pro_teleop/airport_fsm/runtime.py:667` → `False`<br>`r1pro_teleop/airport_fsm/runtime.py:921` → `False`<br>`r1pro_teleop/airport_fsm/runtime.py:971` → `False` |
| `nonfinite_physics` | `r1pro_teleop/airport_fsm/runtime.py:300` → `False` |
| `nonfinite_raw` | `r1pro_teleop/airport_fsm/exporter.py:52` → `False` |
| `nonfinite_replay` | `r1pro_teleop/airport_fsm/exporter.py:119` → `False` |
| `not_settled` | `r1pro_teleop/airport_scenes.py:226` → `生成器捕获ValueError时重采样` |
| `object_count` | `r1pro_teleop/airport_scenes.py:55` → `生成器捕获ValueError时重采样` |
| `object_motion_without_grasp` | `r1pro_teleop/airport_fsm/runtime.py:999` → `False` |
| `online_push_brake_timeout` | `r1pro_teleop/airport_fsm/online_push.py:116` → `False` |
| `online_push_contact_not_restored` | `r1pro_teleop/airport_fsm/online_push.py:112` → `False` |
| `online_push_path_rejected` | `r1pro_teleop/airport_fsm/online_push.py:91` → `False` |
| `online_push_target_rejected` | `r1pro_teleop/airport_fsm/online_push.py:82` → `False` |
| `online_reference_effort_limit` | `r1pro_teleop/airport_fsm/runtime.py:973` → `False` |
| `online_trajectory_error` | `r1pro_teleop/airport_fsm/online_push.py:40` → `False` |
| `operation_budget_exhausted` | `r1pro_teleop/airport_fsm/machine.py:879` → `False` |
| `ordinary_overlap` | `r1pro_teleop/airport_scenes.py:65` → `生成器捕获ValueError时重采样` |
| `path_entry_joint_limit` | `r1pro_teleop/airport_fsm/runtime.py:849` → `True` |
| `phase_duration_budget` | `r1pro_teleop/airport_fsm/runtime.py:728` → `True`<br>`r1pro_teleop/airport_fsm/runtime.py:929` → `True` |
| `physics_environment_changed` | `r1pro_teleop/airport_fsm/batch.py:89` → `False` |
| `physics_time_reset_or_drift` | `r1pro_teleop/airport_fsm/runtime.py:379` → `False` |
| `pinned_lerobot_encoder_api_changed` | `r1pro_teleop/airport_fsm/exporter.py:184` → `False` |
| `placement_needs_correction` | `r1pro_teleop/airport_fsm/machine.py:866` → `not self.c.fixed_primitives` |
| `preflight_required` | `r1pro_teleop/airport_fsm/batch.py:84` → `False` |
| `preplace_bilateral_contact_missing` | `r1pro_teleop/airport_fsm/machine.py:341` → `True` |
| `preplace_clearance_not_restored` | `r1pro_teleop/airport_fsm/machine.py:380` → `True` |
| `primitive_deadline_exceeded` | `r1pro_teleop/airport_fsm/runtime.py:358` → `False` |
| `primitive_excess_servo_deflection` | `r1pro_teleop/airport_fsm/primitives.py:156` → `False`<br>`r1pro_teleop/airport_fsm/primitives.py:324` → `False` |
| `primitive_insufficient_time` | `r1pro_teleop/airport_fsm/primitives.py:89` → `False` |
| `primitive_lift_path_unavailable` | `r1pro_teleop/airport_fsm/primitives.py:195` → `False` |
| `primitive_no_verification_budget` | `r1pro_teleop/airport_fsm/primitives.py:103` → `False` |
| `primitive_path_infeasible` | `r1pro_teleop/airport_fsm/primitives.py:84` → `False` |
| `primitive_place_no_table` | `r1pro_teleop/airport_fsm/primitives.py:216` → `False` |
| `primitive_postcondition_failed` | `r1pro_teleop/airport_fsm/primitives.py:110` → `False` |
| `primitive_push_no_table` | `r1pro_teleop/airport_fsm/primitives.py:335` → `False` |
| `primitive_release_not_verified` | `r1pro_teleop/airport_fsm/primitives.py:293` → `False` |
| `primitive_touchdown_not_observed` | `r1pro_teleop/airport_fsm/primitives.py:130` → `False` |
| `push_accuracy_not_met` | `r1pro_teleop/airport_fsm/machine.py:687` → `not self.c.fixed_primitives` |
| `push_affordance_not_feasible` | `r1pro_teleop/airport_fsm/machine.py:499` → `True` |
| `push_contact_missing` | `r1pro_teleop/airport_fsm/machine.py:535` → `True` |
| `push_lost_support` | `r1pro_teleop/airport_fsm/machine.py:635` → `False`<br>`r1pro_teleop/airport_fsm/online_push.py:97` → `False` |
| `push_no_progress` | `r1pro_teleop/airport_fsm/machine.py:646` → `True` |
| `raw_length_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:50` → `False` |
| `raw_scene_identity_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:47` → `False` |
| `raw_scene_spec_changed` | `r1pro_teleop/airport_fsm/exporter.py:48` → `False` |
| `raw_schema_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:45` → `False` |
| `reach_pull_failed` | `r1pro_teleop/airport_fsm/reach_pull.py:123` → `False` |
| `reach_pull_progress_or_support_failed` | `r1pro_teleop/airport_fsm/reach_pull.py:115` → `False` |
| `reach_pull_sweep_invalid` | `r1pro_teleop/airport_fsm/machine.py:510` → `False` |
| `recovery_support_missing` | `r1pro_teleop/airport_fsm/machine.py:792` → `False` |
| `refuse_overwrite_dataset_link` | `r1pro_teleop/airport_fsm/loading.py:34` → `False` |
| `refuse_overwrite_or_mixed_config` | `r1pro_teleop/airport_fsm/registry.py:72` → `False` |
| `release_not_observed` | `r1pro_teleop/airport_fsm/machine.py:433` → `True` |
| `render_native_contract_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:100` → `False` |
| `replay_diverged` | `r1pro_teleop/airport_fsm/exporter.py:95` → `False` |
| `replay_limit_profile_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:81` → `False` |
| `replay_scene_hash_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:80` → `False` |
| `replay_time_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:96` → `False` |
| `retained_contact_lost` | `r1pro_teleop/airport_fsm/runtime.py:420` → `False` |
| `robot_initial_collision` | `r1pro_teleop/airport_scenes.py:185` → `生成器捕获ValueError时重采样` |
| `scene_count_mismatch` | `r1pro_teleop/airport_fsm/registry.py:20` → `False` |
| `scene_object_count` | `r1pro_teleop/airport_fsm/geometry.py:96` → `False` |
| `scene_preflight_missing` | `r1pro_teleop/airport_fsm/batch.py:242` → `False` |
| `scene_split_leak` | `r1pro_teleop/airport_fsm/loading.py:25` → `False`<br>`r1pro_teleop/airport_fsm/registry.py:153` → `False` |
| `schema_version` | `r1pro_teleop/airport_scenes.py:54` → `生成器捕获ValueError时重采样` |
| `separation_clearance_not_met` | `r1pro_teleop/airport_fsm/machine.py:684` → `True`<br>`r1pro_teleop/airport_fsm/machine.py:731` → `True` |
| `separation_handoff_clearance_unmet` | `r1pro_teleop/airport_fsm/machine.py:656` → `False` |
| `settle_pose_drift` | `r1pro_teleop/airport_scenes.py:257` → `生成器捕获ValueError时重采样`<br>`r1pro_teleop/airport_scenes.py:263` → `生成器捕获ValueError时重采样` |
| `settled_ordinary_overlap` | `r1pro_teleop/airport_scenes.py:219` → `生成器捕获ValueError时重采样` |
| `simulation_time_grid_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:57` → `False` |
| `single_arm_release_path_unavailable` | `r1pro_teleop/airport_fsm/machine.py:469` → `False` |
| `slid_off_table` | `r1pro_teleop/airport_scenes.py:203` → `生成器捕获ValueError时重采样` |
| `slot_outside_belt` | `r1pro_teleop/airport_scenes.py:68` → `生成器捕获ValueError时重采样` |
| `source_changed_after_registration` | `r1pro_teleop/airport_fsm/registry.py:107` → `False` |
| `source_xml_checksum_mismatch` | `r1pro_teleop/airport_fsm/registry.py:48` → `False` |
| `spline_collision_or_wrist` | `r1pro_teleop/airport_fsm/runtime.py:885` → `True` |
| `stale_handoff_tray` | `r1pro_teleop/airport_fsm/machine.py:186` → `False` |
| `terminal_replay_diverged` | `r1pro_teleop/airport_fsm/exporter.py:124` → `False` |
| `test_lift_contact_lost` | `r1pro_teleop/airport_fsm/machine.py:236` → `True` |
| `test_lift_failed` | `r1pro_teleop/airport_fsm/machine.py:244` → `True` |
| `timestamp_grid_mismatch` | `r1pro_teleop/airport_fsm/exporter.py:56` → `False` |
| `tipped` | `r1pro_teleop/airport_scenes.py:202` → `生成器捕获ValueError时重采样` |
| `tray_below_table` | `r1pro_teleop/airport_scenes.py:61` → `生成器捕获ValueError时重采样` |
| `tray_floor_contact` | `r1pro_teleop/airport_scenes.py:195` → `生成器捕获ValueError时重采样` |
| `tray_not_free_body` | `r1pro_teleop/airport_fsm/runtime.py:468` → `False` |
| `tray_on_floor` | `r1pro_teleop/airport_fsm/runtime.py:309` → `False` |
| `unfinalized_existing_shard` | `r1pro_teleop/airport_fsm/exporter.py:164` → `False` |
| `unknown_yaw_contract` | `r1pro_teleop/airport_fsm/geometry.py:110` → `False` |
| `unlimited_actuator` | `r1pro_teleop/airport_fsm/runtime.py:181` → `False` |
| `unregistered_scene_requested` | `r1pro_teleop/airport_fsm/__main__.py:71` → `False`<br>`r1pro_teleop/airport_fsm/batch.py:223` → `False` |
| `unsafe_or_duplicate_scene_id` | `r1pro_teleop/airport_fsm/registry.py:32` → `False` |
| `unsafe_recovery_without_support` | `r1pro_teleop/airport_fsm/machine.py:794` → `False` |
| `unstable_lift` | `r1pro_teleop/airport_fsm/machine.py:267` → `False` |
| `unsupported_nonunit_joint_transmission` | `r1pro_teleop/airport_fsm/runtime.py:186` → `False` |
| `unsupported_separation_path` | `r1pro_teleop/airport_fsm/machine.py:496` → `True` |
| `unsupported_table_naming` | `r1pro_teleop/airport_fsm/geometry.py:116` → `False` |
| `unvalidated_catalog_shard` | `r1pro_teleop/airport_fsm/exporter.py:304` → `False` |
| `unvalidated_shard_in_catalog` | `r1pro_teleop/airport_fsm/registry.py:177` → `False` |
| `wrist_camera_front_guard` | `r1pro_teleop/airport_fsm/runtime.py:314` → `False` |

### 生效配置（含未显式填写的默认值）

正式配置使用 Config.load 合并默认值，不只抄 JSON 中显式字段。smoke 仅在 expected_scenes=12、split_counts=[8,2,2] 上不同。

```json
{
  "fps": 20,
  "expected_scenes": 400,
  "split_counts": [
    300,
    50,
    50
  ],
  "split_seed": 20260916,
  "max_attempts_per_scene": 6,
  "successes_per_scene": 1,
  "max_local_retries": 3,
  "max_operations": 18,
  "max_episode_seconds": 600.0,
  "max_attempt_wall_seconds": 1800.0,
  "max_phase_seconds": 45.0,
  "max_candidate_count": 12,
  "max_ik_iterations": 160,
  "trajectory_mode": "cruise",
  "adaptive_push_distance": false,
  "base_cruise": true,
  "online_push": false,
  "online_push_mode": "position",
  "online_push_seconds": 12.0,
  "online_push_handoff_m": 0.04,
  "stop_push_at_contract": false,
  "consistent_placement": true,
  "single_contact_separation": true,
  "keep_pick_contact": true,
  "keep_place_contact": true,
  "fixed_primitives": true,
  "reach_pull_enabled": false,
  "reach_pull_distance_m": 0.08,
  "reach_pull_dual_radius_m": 0.65,
  "reach_pull_single_radius_m": 0.78,
  "reach_pull_min_progress_m": 0.02,
  "primitive_seconds": 3.0,
  "primitive_lift_m": 0.18,
  "primitive_lift_compensation_m": 0.0,
  "primitive_settle_s": 0.1,
  "primitive_release_clearance_m": 0.02,
  "primitive_touchdown_preload_m": 0.003,
  "primitive_push_compensation_m": 0.035,
  "push_step_max_m": 0.09,
  "free_space_joint_shortcut": true,
  "prefer_direct_grasp": true,
  "robust_planning": false,
  "robust_endpoint_paths": false,
  "ik_reference_regularization": 0.0001,
  "limit_mode": "model80",
  "limit_fraction": 0.8,
  "arm_velocity_fallback": [
    1.5,
    1.5,
    1.5,
    1.5,
    2.2,
    2.2,
    2.2
  ],
  "arm_acceleration": 3.0,
  "arm_jerk": 30.0,
  "gripper_velocity": 0.12,
  "gripper_acceleration": 0.4,
  "gripper_jerk": 4.0,
  "base_speed": 0.6,
  "base_yaw_speed": 0.9,
  "base_acceleration": 0.7,
  "base_yaw_acceleration": 1.2,
  "base_jerk": 3.0,
  "base_yaw_jerk": 5.0,
  "transit_tcp_speed": 0.3,
  "contact_tcp_speed": 0.06,
  "carry_tcp_speed": 0.15,
  "joint_margin_rad": 0.015,
  "ik_position_tolerance_m": 0.04,
  "ik_orientation_tolerance_rad": 0.12,
  "ik_orientation_weight": 0.4,
  "max_ik_branch_step_rad": 0.65,
  "joint_tracking_error_rad": 0.18,
  "tracking_error_grace_s": 0.3,
  "camera_front_margin_m": 0.002,
  "camera_forward_dot": 0.1,
  "camera_guard_mode": "body_ray_cone",
  "camera_self_cone_deg": 5.0,
  "rim_inset_m": 0.01,
  "rim_height_local_m": 0.075,
  "rim_pitch_deg": -35.0,
  "rim_roll_deg": 10.0,
  "pregrasp_clearance_m": 0.15,
  "rim_x_jitter_m": 0.025,
  "gripper_open_m": 0.1,
  "gripper_close_m": 0.0,
  "carry_clearance_m": 0.12,
  "staging_clearance_m": 0.08,
  "push_max_distance_m": 0.18,
  "push_max_yaw_deg": 15.0,
  "push_iterations": 8,
  "planner_margin_m": 0.001,
  "replay_tolerance": 1e-05,
  "include_recovered_in_bc": false,
  "hardware_profile": null,
  "urdf": null,
  "criteria": {
    "position_m": 0.03,
    "yaw_deg": 5.0,
    "tilt_deg": 5.0,
    "gap_min_m": 0.0,
    "gap_max_m": 0.03,
    "stable_s": 1.0,
    "max_speed_m_s": 0.01,
    "penetration_m": 0.003,
    "contact_n": 0.5,
    "lifted_m": 0.02
  }
}
```

### 实现来源指纹

用于发现源码修改后忘记同步规范；不表示新版本已经完成物理验证。

```json
{
  "configs/airport_primitives3.json": "14abc0388f0dc4f205509367c03062d28245c22847bd47771eddfa8986bd6632",
  "configs/airport_primitives3_smoke.json": "7140ea2a22dc0682fab7e4bcbae487858fa42e9cc7026336b9db65f6d3f4737d",
  "configs/airport_reach_pull.json": "d671ec154b2220e3e6c8e51d71bf17ca6f06b34692d06f81f1bdc519d937b036",
  "configs/r1pro_verified_limits_TEMPLATE.json": "b16f846d34e668021f56bf2ca5d5a74eaae2d812f2aa58af64e9f28365b8cb7b",
  "r1pro_teleop/__init__.py": "41ebb66cb9a19e9373a46fbe6075bb25a937c8b2775252c5ac61e6876c820fc6",
  "r1pro_teleop/airport_agent.py": "07ae2365527b4b59b3485bc2fb89982aaa77569e938e972b5e23e234bff6ab8d",
  "r1pro_teleop/airport_annotations.py": "e579cf1b64f0edc0219daa6e87b79d97b8a22c7a6efe6654c7d28e577aae5e95",
  "r1pro_teleop/airport_arrange.py": "9fc3d1b9095cd7fcd60e9274c3c1d629db898fb593de371f0c49db9cc1c23e2a",
  "r1pro_teleop/airport_fsm/__init__.py": "72192a03385ce8ff1970c1f924c1a5e415f638ed76a79eb3ec8fa510ab4ae4ea",
  "r1pro_teleop/airport_fsm/__main__.py": "43dc0927b75422c0a2f90eca56d74c3985627b8115eda2f6d9186f4edc9dffa4",
  "r1pro_teleop/airport_fsm/batch.py": "2c52c2c9208d2655022cebe62b7c40073336677c5fe498593cd1fd7936bba407",
  "r1pro_teleop/airport_fsm/camera_guard.py": "987a37c93996f6650c7b68aafa1921b8fc15c96e6c76844ebce7a94ee65641f0",
  "r1pro_teleop/airport_fsm/contracts.py": "fa6fd6596af755d2c1517e1ecf0d98304fa5aef871fce204f1a088a0aab10d0d",
  "r1pro_teleop/airport_fsm/exporter.py": "ce0da7477e5f74c439aed8fa30474a95ca9dc742f1427ddf651ade18ef8c4e42",
  "r1pro_teleop/airport_fsm/geometry.py": "6cffa006848991b274132d3e846b17b411eb23d814da2766ae59b91646478bf3",
  "r1pro_teleop/airport_fsm/loading.py": "8fe4851d2a2c2baa7cb202a237f716d9f55661fb59f6de7c927264473f95c5b1",
  "r1pro_teleop/airport_fsm/machine.py": "cf1a6f5682fa71d6817e17dde8263897062475a6760503668f7ed054df52c7ec",
  "r1pro_teleop/airport_fsm/online_push.py": "c9fef3c635d889f376ff929ef2591c5d0ed3af428474b3dcbf39247632ed0d43",
  "r1pro_teleop/airport_fsm/primitives.py": "b2e2934746663c6c050f946a45622b5aabdf83aa019abc927942c4be7c13691b",
  "r1pro_teleop/airport_fsm/reach_pull.py": "50f6e6d841e3c821f12dfbc2b56b1f5e8a01a0fae48a0acc98320539db731b9d",
  "r1pro_teleop/airport_fsm/registry.py": "ee85018a7d6cc6552a60d871a9c7596151c59e68aeb5c437c602fa29d9bfe81b",
  "r1pro_teleop/airport_fsm/runtime.py": "d84622ca9e8f2d44478792202e86f2656a1c76a132f1b3b544c8796c49e413ea",
  "r1pro_teleop/airport_fsm/task_dag.py": "50061d1ee96674979f33f28d07822899712cb89e0096e8b440b450877f8a41a2",
  "r1pro_teleop/airport_fsm/trace.py": "afa6d6f8dbb5f90b3fdf3d1da0f52c2e53122050d1f3b394e1d6cd3c728a7865",
  "r1pro_teleop/airport_fsm/trajectory.py": "2fe4747e031428d8becd37fac7137ac69ff1fff2aa886681c3045bf0ae892279",
  "r1pro_teleop/airport_mobile.py": "1059024b0ffe940518261ec933b0190d10965856b0ef26fc7b500e513578b5cc",
  "r1pro_teleop/airport_pipeline.py": "12b968bba247953b2cbc093aac8df4e453d7bfbcf749113d33e58ce6e0696875",
  "r1pro_teleop/airport_recording.py": "520d76b855c0aa0787852d30e0ce4f9cd5c68bc92d161b1a2dc0068fd34038b6",
  "r1pro_teleop/airport_scenes.py": "ec6c183d8efb6bec1a0fbf856ff6429120fbd53b2165f88f93be692e3c565f05",
  "r1pro_teleop/airport_service.py": "2d174106f961da25484386a19a463e79caca5480d8df7e77f5c247e409791c49",
  "r1pro_teleop/build_assets.py": "edf4962bb6833441cec9627b8e5ecebf1b94bb461a31832ea712920cf2b9c110",
  "r1pro_teleop/core.py": "80ffbda1521934b15f3fefe9e560c482a4e7f26445f4f4d6581d5e169ef79e73",
  "r1pro_teleop/dataset.py": "912baa515dd4a740d092911311354914debde4261baa07395855385297c5ffec",
  "r1pro_teleop/quality.py": "1f1ac509818da7475e43dea49987b9e93fb2943a58b9208ea4a8f5641d7397d2",
  "r1pro_teleop/quest_bridge.py": "2288fd3ee9008060833c7a9e513da2bd2aa3145ae9679e036ad636e78dab6cda",
  "r1pro_teleop/quest_relay.py": "43413964aca895a21e5b564ef2b51315a0a374caaa0305304dc0855679ad9882",
  "r1pro_teleop/real_calibration.py": "b617e6a6b1d9962b5845986c5f994325d54fb8bcdf04e3bd798edfcb972f6de0",
  "r1pro_teleop/replay.py": "35e5be05da68d45f3497003ecf7f04c7a1799efd197c7486504f8a19f5bb6d41",
  "r1pro_teleop/server.py": "88e8e7117bb4e894722cf853689b411426e01daf098357dc3d7917c7c05c6f5d",
  "r1pro_teleop/smoke.py": "fa5be8b9c39138d7016dbf3dade2c7d5205390593585fe4296ce912a22d6e1d1",
  "r1pro_teleop/workspace_check.py": "0889fd60282f650e5b0e7164c6a28686b7bbf20d905750e86c836e59dcb19c3e",
  "schemas/airport_scene_v1.schema.json": "9c13f5c0a83749e441b5af2a5ce879a1bf9a6b1ba8fbc6adf58de16d80dc991b",
  "schemas/airport_scene_v1_1.schema.json": "6981a89f401e4fbf7d647e635e42c0638775e7e6971fbf432f77be3369e6f641",
  "scripts/collect_airport_batches.py": "f32cdf5e5b1dadc29c2763cd732371e362c7e755b088fd0568fe665f1d636223",
  "scripts/generate_airport_scenes.py": "5bc9b26ad3b9ff765f90e0b09cce71839947bb20b864e6f0fee5f13d2884585e",
  "scripts/project.py": "fdc97d51da26450406f1ef028b96217f8455478924eb1697684cbcd10c851f4f",
  "scripts/repair_airport_initial_settle.py": "ed80b3e007a88cc13121607f69c0d96dfcdd45e1eb238726a2674bc41cb7244f",
  "scripts/sync_task_spec.py": "76fac95422a73c1f529c413eab61b65b80519f4f47429e273dd62f7c8b208f45",
  "scripts/upgrade_airport_fourcam.py": "ecca8b1d01f5833919477a090b57de4f144e858a1f4dc28bbf293f7e0b14e85c"
}
```
<!-- GENERATED-CONTRACT:END -->
