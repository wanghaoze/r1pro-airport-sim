from types import SimpleNamespace
import numpy as np
import pytest
from r1pro_teleop.airport_fsm.machine import Machine
from r1pro_teleop.airport_fsm.contracts import Config, Fault


def fixture(held=False):
    m=Machine.__new__(Machine);m.c=Config();m.pending_grasp_contact=None
    m._poses=lambda:np.zeros((3,7));m.transition=lambda *a,**k:None
    calls=[];m.log=SimpleNamespace(event=lambda *a,**k:calls.append(('event',a[0])))
    def cartesian(*a,**k):
        calls.append(('preview' if k.get('preview_only') else 'execute',None))
        raise Fault('ik_unreachable' if k.get('preview_only') else 'test_stop',recoverable=True)
    m.r=SimpleNamespace(holding=0 if held else None,retained_contact=None,target_slot=2,
        observation=lambda:{'gripper_contact_force':np.zeros((3,2))},
        rim_goals=lambda *a,**k:{},cartesian=cartesian,tucked=np.zeros(16),
        joints=lambda *a,**k:calls.append(('tuck',None)))
    def align(*a,**k):
        assert k=={'require_contact_approach':True};calls.append(('align',a));return .2,0.
    m.align=align
    return m,calls


def test_failed_private_approach_reselects_before_any_contact_execution():
    m,calls=fixture()
    with pytest.raises(Fault,match='test_stop'):m.grasp(0,0.,0.)
    assert [c[0] for c in calls]==['preview','event','tuck','align','execute']
    assert calls[3][1]==(0,2)


def test_held_payload_never_navigates_on_approach_failure():
    m,calls=fixture(held=True)
    with pytest.raises(Fault,match='ik_unreachable'):m.grasp(0,0.,0.)
    assert [c[0] for c in calls]==['preview']
