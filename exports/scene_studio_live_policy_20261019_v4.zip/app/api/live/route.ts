import {assert} from '@/lib/core';
import {body,database,error,gpuOperator,json,worker} from '@/lib/server';
const valid=(id:unknown)=>typeof id==='string'&&/^[A-Za-z0-9_-]{8,80}$/.test(id);
export async function PUT(request:Request){try{
  worker(request);const data=await body(request);assert(valid(data.jobId),'Invalid live job ID');
  assert(data.simulationOnly===true&&Number.isFinite(data.sampledAt),'Invalid live snapshot');
  await database().prepare('INSERT INTO agent_state(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at').bind('live:'+data.jobId,JSON.stringify(data),Date.now()).run();
  return json({ok:true});
}catch(e){return error(e);}}
export async function GET(request:Request){try{
  gpuOperator(request);const id=new URL(request.url).searchParams.get('jobId');assert(valid(id),'Select a live evaluation');
  const row=await database().prepare('SELECT value,updated_at FROM agent_state WHERE key=?').bind('live:'+id).first<any>();
  return json(row?{...JSON.parse(row.value),receivedAt:row.updated_at}:{jobId:id,stage:'awaiting_worker',frame:null,downloads:[]});
}catch(e){return error(e);}}
