import test from 'node:test';
import assert from 'node:assert/strict';
import {flexibleTrainingPlan,evaluationPlan} from '../lib/training.ts';
const snapshot={datasets:[{id:'real_pickplace_v2'},{id:'isaac300_20261017'}],checkpoints:[{id:'saved',closed:true},{id:'writing',closed:false}]};
test('ratio endpoints omit unused domains and exact target is retained',()=>{
  const p=flexibleTrainingPlan({datasetIds:['real_pickplace_v2','isaac300_20261017'],realPercent:100,steps:500},snapshot);
  assert.deepEqual(p.datasets,['real_pickplace_v2']);assert.equal(p.steps,500);
  assert.throws(()=>flexibleTrainingPlan({datasetIds:['real_pickplace_v2'],realPercent:1,steps:500},snapshot));
  assert.throws(()=>flexibleTrainingPlan({datasetIds:['real_pickplace_v2'],realPercent:101,steps:500},snapshot));
});
test('MSE rejects train and unclosed checkpoints',()=>{
  assert.throws(()=>evaluationPlan({kind:'evaluation.mse',checkpointIds:['writing'],split:'test'},snapshot));
  assert.throws(()=>evaluationPlan({kind:'evaluation.mse',checkpointIds:['saved'],split:'train'},snapshot));
  assert.equal(evaluationPlan({kind:'evaluation.mse',checkpointIds:['saved'],split:'val'},snapshot).stride,1);
});
test('VLA preserves train-scene diagnostic and explicit base actuator mask',()=>{
  const p=evaluationPlan({kind:'evaluation.vla',checkpointIds:['saved'],sceneSetId:'isaac32_20261017',roomIds:[0,31],framesPerAction:200},snapshot);
  assert.equal(p.teacherFallback,false);assert.equal(p.heldOutGeneralization,false);
  assert.throws(()=>evaluationPlan({kind:'evaluation.vla',checkpointIds:['saved'],sceneSetId:'isaac32_20261017',roomIds:[0,0],framesPerAction:200},snapshot));
});

test('live run freezes independent simulation and wall time budgets for one room',()=>{
 const req={kind:'evaluation.live',checkpointIds:['saved'],sceneSetId:'isaac32_20261017',roomIds:[31],framesPerAction:200,transport:'ros2',maxSimulationSeconds:10,maxWallSeconds:600,inferenceTimeoutSeconds:30};
 const p=evaluationPlan(req,snapshot);assert.equal(p.maxSimulationSeconds,10);assert.equal(p.maxWallSeconds,600);assert.equal(p.inferenceTimeoutSeconds,30);assert.deepEqual(p.roomIds,[31]);assert.equal(p.trainingEligible,false);
 for(const change of [{roomIds:[0,1]},{maxSimulationSeconds:0},{maxSimulationSeconds:NaN},{maxSimulationSeconds:121},{inferenceTimeoutSeconds:0},{maxWallSeconds:Infinity},{transport:'file'}])assert.throws(()=>evaluationPlan({...req,...change},snapshot));
});
